// script.js
// Archivo preparado para futuras interacciones

console.log("Bienvenido al sitio de Salud SENA");

// Aquí podrías agregar funciones de navegación, sliders, formularios, etc.
