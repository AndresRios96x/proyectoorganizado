// Script vacío por ahora. Aquí puedes manejar validaciones, envíos, etc.
console.log("Formulario de registro cargado.");
