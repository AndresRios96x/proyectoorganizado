// script.js - aquí puedes agregar funcionalidades personalizadas con JavaScript

// Ejemplo: mensaje en consola cuando se carga la página
document.addEventListener('DOMContentLoaded', function () {
  console.log("Página cargada correctamente.");
});
